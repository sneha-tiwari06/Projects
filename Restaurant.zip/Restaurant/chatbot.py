from pywebio.platform import*
from cgitb import html
from pywebio.input import*
from pywebio.output import put_html,put_loading,put_text,put_image
from pywebio.session import*
import mysql.connector

db1 = mysql.connector.connect(
  host="localhost",
  user="root",
  password="Enter your Mysql Password.",
  database='Enter your database name')
cur=db1.cursor()
put_html('<html><head><style>img{opacity:0.15;position:absolute;left:10px; bottom:10px;}</style></head><body><img src="https://i.ibb.co/n3yp6TX/png-clipart-medicine-physician-health-care-medical-record-patient-health-thumbnail-removebg-preview.png" id=img; style="width:500%; height:200%;"></body></html>')


put_html('<html><head></head><body><center><img src="https://i.ibb.co/gdKdTMS/dio.png" height="100" width="100"></center></body></html>')
put_html('<html><head><style>textarea {font-family:"Lucida Console", "Courier New", monospace;font-style:oblique;font-size:15.5px;resize:none;position:absolute;bottom:75px;left:0px;width:300px;height:150px;background-color:white;border:5px solid gray;box-shadow:5px 10px;background-color:gray; }</style></head><body><textarea id="Ptyhon" name="Developers" rows="4" cols="50" readonly>         HOW TO USE?    \nAnswer "Do You" Questions in format as written below \n"Y" for Yes\n"N" for No.</textarea></body></html>')
put_html('<!DOCTYPE html<head><title>CSS Box Model</title><style>.main {position:fixed;right:0px;bottom:0px;font-size: 16px;font-weight: bold;Text-align: center;}.gfg {position:fixed;right:0px;bottom:0px;margin-left: 60px;border: 30px solid #009900;width: 300px;height: 200px;text-align: center;padding: 50px;}.gfg1 {font-alignment:center;font-size: 15px;font-weight: bold;color: #009900;margin-top: -48px;}.gfg2 {text-alignment:center;font-size: 12px;font-weight: bold;}</style></head><body><div class="main"></div><div class="gfg"><div class="gfg1">Platform and Language Used</div><div class="gfg2"><br>PYTHON<br>CSS<br>HTML<br>PYWEBIO</div></div></body></html>')
put_html('<html><head><meta name="viewport" content="width=device-width, initial-scale=1"><style>body {position:relative;margin: 0;font-family: Arial, Helvetica, sans-serif;}.topnav {position:relative;overflow: hidden;background-color: #333;}.topnav a {position:relative;float: left;color: #f2f2f2;text-align: center;padding: 14px 16px;text-decoration: none;font-size: 17px;}.topnav a:hover {background-color: #FF0000;color: black;}.topnav a.active {background-color:#FF0000;color:white;}</style></head><body><div class="topnav"><a class="active" href="">&nbsp &nbsp &nbsp &nbsp Home &nbsp &nbsp &nbsp &nbsp</a></a><a href=http://127.0.0.1:5500/index.html>&nbsp &nbsp Contact &nbsp &nbsp</a><a href="http://127.0.0.1:5500/about.html"> &nbsp About &nbsp &nbsp</a></div><div style="padding-left:16px"><h1 style="color:red;font-size:20px;font-weight:bold;margin-center:100%;margin-top:8%;margin-bottom:5%;font-size:25px;text-align:center;background-color:black")>Welcome to the disease detector program</h1><p></p></div></body></html>')


print("Connected")

Name=input("Enter your Name")
a=input("Which disease do you think you suffer from? ").lower()

if a=="fever":
    c=input("Do you have headche ").lower()
    if c=="y":
        d=input("Do you feel unconscious").lower()
        if d=="y":
            e=input("Do you feel shivering?").lower()
            if e=="y":
               result="\n\nThere is 70% proability that you suffer from fever\n\nThese are some hospitals:\n\n1.Sancheti Hospital\n\n2.Pune Hospital\n\n3.Ruby Hall Clinic"
               put_text(result).style('font-weight:bold;font-style:bold;color:red;vertical-align:middle;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
            else:
                    e==input("Do you feel cold").lower()
                    if e=="n":
                        g=input("Are you feeling low?").lower()
                        if g=="y":
                           result="\n\n\n\n\nThis might be due to changing weather"
                           put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
                    else:
                        result="\n\n\n\nThis might be due to consumption of cold substances"
                        put_text(result).style('font-weight:bold;font-style:italic;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
        else:
            q=input("Do you have sense of smell").lower()
            p=input("Do you have taste sense").lower()
            if q=="y" and p=="y":
                result="\n\n\n\nYou have both cold and Fever"
                put_text(result).style('font-weight:bold;font-style:italic;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
            elif q=="y" and p=="n":
                    result="\n\n\n\nThere is 50% probability that you might be suffering from fever"
                    put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
            elif q=="n" and p=="n":
                        result="\n\n\n\nNo you don't suffer from fever!Thank's For using"
                        put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
            elif q=="n" and p=="y":
                            result="\n\n\n\nThere is 20% proability"
                            put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
            else:
                 result="\n\n\n\nSorry We Don't Understand your request"
                 put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
                
            
            
    else:
        w=input("Do you feel unhappy").lower()
        k=input("Do you feel unfocused").lower()
        if w=="y" and k=="y":
                result="\n\nDepression\n \n\nPlease Contact Us on 7296892862 right now."
                put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
        else:
                   result="\n\n\nMaybe this is because of mild tension"
                   put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')

                

    
elif a=="headache":
    o=input("Which part of your brain has ache?Forehead of Backhead").lower()
    if o=="forehead":
        result="\n\nGet a Aspirin Tablet from the medical\n\n\n\nThese are some of medicals where you can find Aspirin\n1.Staywell Medical, NC KELKAR ROAD\n2.Vijay Medicals,MG ROAD"
        put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
    elif o=="backhead":
        result="\n\n\n\nGet SARIDON ADVANCE Tablet or if the pain is severe consult a doctor.\n\n\nThese are some of hospitals\n1.Sasoon Hospital"
        put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
    else:
        result="\n\n\n\nConsult a doctor"
        put_text(result).style('font-weight:bold;font-style:italic;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
elif a=="stomachache":
    v=input("Do you suffer from Acidity").lower()
    if v=="y":
        result="\n\n\nFind any Antacid Tablets"
        put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
    elif v=="n":
        result=("\n\n\nThere may be infection.Please Consult Doctors ASAP\n\n\n\nThese are some of Doctors\n\n\nHarshal Gadhikar\n\n\nRajendra Pujari")
        put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;') 
    else:
        result=("\n\n\nConsult a Doctor")
        put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')    
elif a=="depression":
    z=input("Do you feel Anxious").lower()
    if z=="y":
        result=("\n\n\nPlease Contact 7296892862 number and let our executive know your address")
        put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
    elif z=="n":
        result=("\n\n\nPlease feel free to talk to your family members and find Therapist.Sab Kuch Thik Hojyega")
        put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
    else:
        result=("\n\n\n\nContact 7296892862")  
        put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')  
elif a=="dizziness":
    xz=input("Do you lose sight and feel unconscious").lower()
    if xz=="y":
        result=("\n\nConsult a doctor or prefer a nearest clinic\n\nThese are some clinics\n\n1.Apollo CLinic,ITI Road Aundh\n\nMulticare Clinic,Opp Kesari Wada")
        put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
    elif xz=="n":
        result=("\n\n\nGet glucose from the nearest medical\n\nThese are some of medicals\n\n1.Wellness Forever,Aundh\n\n2.Sameer Pharms,SB Road")
        put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
    else:
        result=("\n\n\n\nConsult Doctor")
        put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')
else:
    result=("\n\n\nSorry we didn't understand your request!Our developers are trying their best to make the program best.")
    put_text(result).style('font-weight:bold;color:red;text-align:center;letter-spacing:3px;line-height:30px;word-spacing:10px;font-family:"Arial, Helvetica, sans-serif";Font-size:30px;')        
    
         
x="INSERT INTO enter the table name (Disease(//column name in table),Name(//column name in table) VALUES(%s,%s)"
t=(a,Name)
cur.execute(x,t)
db1.commit()
